<html>
<head>
    <title>Remove From Database</title>

    <!-- load CSS files -->
    <link rel="stylesheet" type="text/css" href="styles.css"/>
    
    <!-- Load fonts -->
    <link href="http://fonts.googleapis.com/css?family=Sanchez" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,700,600,800,900' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
    <link href="http://fonts.googleapis.com/css?family=Nobile" rel="stylesheet" type="text/css">			
</head>

<body>

    <div id="header" style="margin-bottom:80px;">
	<div class="textCenter">
            <img src="pictures/dragon.png">
	</div>
        <div style="margin-top:20px;">
	    <a class="links" style="margin-left: 5%;" href=add.html>Add Movie</a>
            <a class="links" style="margin-left: 5%;" href=update.php>Update Movie</a>
            <a class="links" style="margin-left: 5%;" href=remove.php>Remove Movie</a>
	    <a class="mainlink" href=index.html>MonsterMovies.com</a>     
            <a class="links" style="margin-left: 6%;" href=browse.php> Browse Movies</a>
            <a class="links" style="margin-left: 6%;" href=about.html>About</a>
            <a class="links" style="margin-left: 6%;" href=contact.html>Contact Us</a>
	</div>
    </div>
</body>

<?php

 $host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password 
$db_name="Project"; // Database name 

// Connect to server and select database.
 mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
 mysql_select_db("$db_name")or die("cannot select DB");

// select record from mysql 
 $sql="SELECT * FROM Movies, Reviews WHERE Movies.Movie_Name = Reviews.Movie_Name AND Movies.Year = Reviews.Year ORDER BY Movies.Year DESC, Movies.Movie_Name";
 $result=mysql_query($sql);
?>

 <table class="textCenter" width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
 <tr>
 <td align="center" colspan="9" bgcolor="#FFFFFF"><strong>Remove Movie From Database</strong> </td>
 </tr>

 <tr>
 <td align="center" bgcolor="#FFFFFF"><strong>Name</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Year</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Studio</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Director</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Runtime</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Rating</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Reviewer</strong></td>
 <td align="center" bgcolor="#FFFFFF"><strong>Review</strong></td>
 <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
 </tr>

 <?php
 while($rows=mysql_fetch_array($result)){
 ?>


 <tr>
 <td bgcolor="#FFFFFF"><?php echo $rows['Movie_Name']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Year']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Studio']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Director']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Runtime']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Rating']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Reviewer']; ?></td>
 <td bgcolor="#FFFFFF"><?php echo $rows['Review']; ?></td>
 <td bgcolor="#FFFFFF"><a href="delete_ac.php?name=<?php echo $rows['Movie_Name']; ?>&year=<?php echo $rows['Year']; ?>">delete</a></td>
 </tr>

 <?php
 // close while loop 
 }
 ?>

 </table>

<?php
// close connection; 
 mysql_close();
 ?>

<footer style="margin-top:80px;">

    <div style="color:#777777" class="textCenter darkGreyBackground">
	<h2>Monster Movies Inc.</h2>
	<div class="foot-sep"></div>
	<p>&copy; 2014 Andre Stockling. All Rights Reserved.</p>
	<p><a href=contact.html>Contact Us</a>  |  St. Paul, Minnesota | 
	<a href=#>Back to the top</a></p>
<!-- Creates space at the bottom of the page, Nothing else worked -->
<br><br>
    </div>
</footer>

</html>
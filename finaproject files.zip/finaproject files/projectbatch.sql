CREATE DATABASE Project;

Use Project;

CREATE TABLE Movies (
Movie_Name VARCHAR(40),
Year INT(40),
Studio VARCHAR(40),
Director VARCHAR(40),
Runtime VARCHAR(10),
Rating VARCHAR(10),
primary key (Movie_Name, Year)
);

insert into Movies values
("World War Z","2013", "Paramount Pictures", "Marc Forster", "115", "7.1"),
("Chernobyl Diaries",2012, "Warner Bros Pictures", "Bradley Parker", "86", "5.0"),
("Vanishing On 7th Street",2010, "Magnet Releasing", "Brad Anderson", "91", "4.9");

CREATE TABLE Reviews (
Movie_Name VARCHAR(40),
Year INT(40),
Reviewer VARCHAR(40),
Review VARCHAR(500),
primary key (Review),
FOREIGN KEY (Movie_Name, Year) REFERENCES Movies(Movie_Name, Year)
);

insert into Reviews values
("World War Z", 2013, "Andre Stockling", "Not suprisingly, this zombie flick is considered an action movie by some. While it is not a traditional horror movie I believe that it does belong on this site due to the zombie theme. The action begins climbing very early on and for the most part continues to grow throughout the movie. We watch as Brad Pitt travels the world looking for the source of a horrific disease that is turning people into zombies. I don't want to spoil the movie, so just suffice it to say that his adventure features many close encounters. While most wouldn't be consider World War Z to be particularily scary or gruesome, it is entertaining. I thought this was a really good movie and would reccomend it to zombie lovers and action movie lovers alike." ),
("Chernobyl Diaries", 2012, "Andre Stockling", "Personally, I have always felt that the scariest movies were movied based around real and plausible events. This is the reason I was excited to see Chernobyl Diaries. Basing a horror movie around the actual nuclear meltdown in Ukraine 20 years ago had great potential. Unfortunately, this potential wasn't met and instead we got a rather boring and generic film. Aside from a few jump scares there isn't much to see here. However I'm holding out hope that Bradley Parker's second attempt at directing does not go as poor as this one did."),
("Vanishing On 7th Street", 2010, "Andre Stockling", "Apparently I am the only one who liked this movie");




<html>

<head>
    <title>Browse Database</title>

    <!-- load CSS files -->
    <link rel="stylesheet" type="text/css" href="styles.css"/>
    
    <!-- Load fonts -->
    <link href="http://fonts.googleapis.com/css?family=Sanchez" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,700,600,800,900' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Great+Vibes' rel='stylesheet' type='text/css'>
    <link href="http://fonts.googleapis.com/css?family=Nobile" rel="stylesheet" type="text/css">			
</head>

<body>

    <div id="header" style="margin-bottom:80px;">
	<div class="textCenter">
            <img src="pictures/dragon.png">
	</div>
        <div style="margin-top:20px;">
	    <a class="links" style="margin-left: 5%;" href=add.html>Add Movie</a>
            <a class="links" style="margin-left: 5%;" href=update.php>Update Movie</a>
            <a class="links" style="margin-left: 5%;" href=remove.php>Remove Movie</a>
	    <a class="mainlink" href=index.html>MonsterMovies.com</a>     
            <a class="links" style="margin-left: 6%;" href=browse.php> Browse Movies</a>
            <a class="links" style="margin-left: 6%;" href=about.html>About</a>
            <a class="links" style="margin-left: 6%;" href=contact.html>Contact Us</a>
	</div>
    </div>
</body>

<?php
 $con=mysqli_connect("localhost","root", "", "Project");
 // Check connection
 if (mysqli_connect_errno()) {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }

// escape variables for security
$moviename = mysqli_real_escape_string($con, $_POST['moviename']);
$year = mysqli_real_escape_string($con, $_POST['year']);
$studio = mysqli_real_escape_string($con, $_POST['studio']);
$director = mysqli_real_escape_string($con, $_POST['director']);
$runtime = mysqli_real_escape_string($con, $_POST['runtime']);
$rating = mysqli_real_escape_string($con, $_POST['rating']);
$reviewer = mysqli_real_escape_string($con, $_POST['reviewer']);
$review = mysqli_real_escape_string($con, $_POST['review']);

$sql="INSERT INTO Movies
VALUES ('$moviename', $year, '$studio', '$director', '$rating', '$runtime')";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}

$sql="INSERT INTO Reviews
VALUES ('$moviename', $year, '$reviewer', '$review')";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}

mysqli_close($con);
?>

<p style="text-decoration:none; font-size:25px;" class="textCenter">Movie added successfully. Click <a href=add.html>here</a> to add another movie, or go to <a href=browse.php>browse</a></html> to view the entire movie database</p>

<footer style="margin-top:80px;">

    <div style="color:#777777" class="textCenter darkGreyBackground">
	<h2>Monster Movies Inc.</h2>
	<div class="foot-sep"></div>
	<p>&copy; 2014 Andre Stockling. All Rights Reserved.</p>
	<p><a href=contact.html>Contact Us</a>  |  St. Paul, Minnesota | 
	<a href=#>Back to the top</a></p>
<!-- Creates space at the bottom of the page, Nothing else worked -->
<br><br>
    </div>
</footer>
</html>